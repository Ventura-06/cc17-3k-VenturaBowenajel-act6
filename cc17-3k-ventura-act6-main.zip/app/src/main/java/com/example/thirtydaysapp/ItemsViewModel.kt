package com.example.thirtydaysapp

data class ItemsViewModel(val title: String, val des: String, val imageResId: Int)
